/*
# Create products table for RO t-shirt store

1. New Tables
- `products`
  - `id` (uuid, primary key)
  - `name` (text, not null) - t-shirt name
  - `description` (text, not null) - product description
  - `price` (numeric, not null) - price in USD
  - `image_url` (text, not null) - product image URL (flat-lay / no human figures)
  - `sizes` (text[], not null default) - available sizes
  - `colors` (text[], not null default) - available colors
  - `category` (text, not null default 't-shirt') - product category
  - `in_stock` (boolean, not null default true) - availability flag
  - `featured` (boolean, not null default false) - featured on homepage
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `products`.
- Allow anon + authenticated SELECT (public storefront).
- Allow anon + authenticated INSERT/UPDATE/DELETE (admin management without auth, per single-tenant no-auth pattern).
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  image_url text NOT NULL,
  sizes text[] NOT NULL DEFAULT ARRAY['S', 'M', 'L', 'XL'],
  colors text[] NOT NULL DEFAULT ARRAY['Black', 'White'],
  category text NOT NULL DEFAULT 't-shirt',
  in_stock boolean NOT NULL DEFAULT true,
  featured boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);
