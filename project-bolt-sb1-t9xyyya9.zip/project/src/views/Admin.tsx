import { useEffect, useState } from 'react';
import { supabase, type Product } from '../lib/supabase';
import {
  Plus,
  Trash2,
  Loader2,
  X,
  Check,
  Pencil,
  Star,
  Package,
} from 'lucide-react';

const DEFAULT_SIZES = ['S', 'M', 'L', 'XL'];
const DEFAULT_COLORS = ['Black', 'White'];

type FormState = {
  name: string;
  description: string;
  price: string;
  image_url: string;
  sizes: string[];
  colors: string[];
  category: string;
  in_stock: boolean;
  featured: boolean;
};

const emptyForm: FormState = {
  name: '',
  description: '',
  price: '',
  image_url: '',
  sizes: DEFAULT_SIZES,
  colors: DEFAULT_COLORS,
  category: 't-shirt',
  in_stock: true,
  featured: false,
};

export default function Admin() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [sizeInput, setSizeInput] = useState('');
  const [colorInput, setColorInput] = useState('');

  async function load() {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setProducts(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setSizeInput('');
    setColorInput('');
  };

  const openAdd = () => {
    resetForm();
    setShowForm(true);
  };

  const openEdit = (product: Product) => {
    setForm({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      image_url: product.image_url,
      sizes: product.sizes,
      colors: product.colors,
      category: product.category,
      in_stock: product.in_stock,
      featured: product.featured,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.description || !form.price || !form.image_url) return;
    setSaving(true);
    const payload = {
      name: form.name,
      description: form.description,
      price: parseFloat(form.price),
      image_url: form.image_url,
      sizes: form.sizes,
      colors: form.colors,
      category: form.category,
      in_stock: form.in_stock,
      featured: form.featured,
    };
    if (editingId) {
      const { error } = await supabase
        .from('products')
        .update(payload)
        .eq('id', editingId);
      if (error) setError(error.message);
    } else {
      const { error } = await supabase.from('products').insert(payload);
      if (error) setError(error.message);
    }
    setSaving(false);
    if (!error) {
      setShowForm(false);
      resetForm();
      load();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) setError(error.message);
    else load();
  };

  const addSize = () => {
    const s = sizeInput.trim().toUpperCase();
    if (s && !form.sizes.includes(s)) {
      setForm({ ...form, sizes: [...form.sizes, s] });
      setSizeInput('');
    }
  };

  const removeSize = (s: string) => {
    setForm({ ...form, sizes: form.sizes.filter((x) => x !== s) });
  };

  const addColor = () => {
    const c = colorInput.trim();
    if (c && !form.colors.includes(c)) {
      setForm({ ...form, colors: [...form.colors, c] });
      setColorInput('');
    }
  };

  const removeColor = (c: string) => {
    setForm({ ...form, colors: form.colors.filter((x) => x !== c) });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="text-xs font-medium tracking-[0.3em] uppercase text-ink-400 mb-2">
            Manage
          </p>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
            Products
          </h1>
        </div>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-ink-900 text-white px-5 py-3 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add product
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 mb-6">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-ink-400" />
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-24 border border-dashed border-ink-200 rounded-3xl">
          <div className="w-14 h-14 bg-ink-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package className="w-6 h-6 text-ink-300" />
          </div>
          <h3 className="font-display text-xl font-bold mb-1">No products yet</h3>
          <p className="text-ink-500 text-sm mb-5">
            Add your first t-shirt to the store.
          </p>
          <button
            onClick={openAdd}
            className="inline-flex items-center gap-2 bg-ink-900 text-white px-5 py-3 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add product
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {products.map((product) => (
            <div
              key={product.id}
              className="group border border-ink-100 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="aspect-[4/5] bg-ink-50 relative overflow-hidden">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  {product.featured && (
                    <span className="bg-white text-ink-900 text-[10px] font-semibold tracking-widest uppercase px-2.5 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-3 h-3 fill-ink-900" />
                      Featured
                    </span>
                  )}
                  {!product.in_stock && (
                    <span className="bg-ink-900 text-white text-[10px] font-semibold tracking-widest uppercase px-2.5 py-1 rounded-full">
                      Sold out
                    </span>
                  )}
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start gap-2 mb-1">
                  <h3 className="font-medium text-ink-900 truncate">{product.name}</h3>
                  <p className="font-display font-semibold whitespace-nowrap">
                    ${product.price.toFixed(2)}
                  </p>
                </div>
                <p className="text-xs text-ink-400 mb-3 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => openEdit(product)}
                    className="flex-1 flex items-center justify-center gap-1.5 border border-ink-200 text-ink-700 py-2 rounded-lg text-xs font-medium hover:bg-ink-50 transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="flex items-center justify-center gap-1.5 border border-ink-200 text-ink-500 py-2 px-3 rounded-lg text-xs font-medium hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
                    aria-label="Delete product"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-ink-950/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="sticky top-0 bg-white flex items-center justify-between px-6 py-5 border-b border-ink-100 rounded-t-3xl">
              <h2 className="font-display text-xl font-bold">
                {editingId ? 'Edit product' : 'Add product'}
              </h2>
              <button
                onClick={() => {
                  setShowForm(false);
                  resetForm();
                }}
                className="p-2 hover:bg-ink-50 rounded-full transition-colors"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="px-6 py-6 space-y-5">
              <div>
                <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                  Name
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Heavyweight Tee — Onyx"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                  Description
                </label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="240gsm heavyweight cotton with a structured, regular fit."
                  required
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                    Price (USD)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                    placeholder="42.00"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                    Category
                  </label>
                  <input
                    type="text"
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                  Image URL
                </label>
                <input
                  type="url"
                  value={form.image_url}
                  onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                  placeholder="https://images.pexels.com/..."
                  required
                  className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                />
                {form.image_url && (
                  <div className="mt-3 w-32 h-40 bg-ink-50 rounded-xl overflow-hidden">
                    <img
                      src={form.image_url}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
              </div>

              {/* Sizes */}
              <div>
                <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                  Sizes
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {form.sizes.map((s) => (
                    <span
                      key={s}
                      className="inline-flex items-center gap-1.5 bg-ink-100 text-ink-800 text-sm font-medium px-3 py-1.5 rounded-lg"
                    >
                      {s}
                      <button
                        type="button"
                        onClick={() => removeSize(s)}
                        className="text-ink-400 hover:text-ink-900"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={sizeInput}
                    onChange={(e) => setSizeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addSize();
                      }
                    }}
                    placeholder="Add size"
                    className="flex-1 px-3 py-2 rounded-lg border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                  />
                  <button
                    type="button"
                    onClick={addSize}
                    className="px-4 py-2 bg-ink-100 text-ink-800 rounded-lg text-sm font-medium hover:bg-ink-200 transition-colors"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Colors */}
              <div>
                <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                  Colors
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {form.colors.map((c) => (
                    <span
                      key={c}
                      className="inline-flex items-center gap-1.5 bg-ink-100 text-ink-800 text-sm font-medium px-3 py-1.5 rounded-lg"
                    >
                      {c}
                      <button
                        type="button"
                        onClick={() => removeColor(c)}
                        className="text-ink-400 hover:text-ink-900"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={colorInput}
                    onChange={(e) => setColorInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addColor();
                      }
                    }}
                    placeholder="Add color"
                    className="flex-1 px-3 py-2 rounded-lg border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                  />
                  <button
                    type="button"
                    onClick={addColor}
                    className="px-4 py-2 bg-ink-100 text-ink-800 rounded-lg text-sm font-medium hover:bg-ink-200 transition-colors"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Toggles */}
              <div className="flex flex-col gap-3 pt-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-sm font-medium text-ink-900">In stock</span>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, in_stock: !form.in_stock })}
                    className={`relative w-11 h-6 rounded-full transition-colors ${
                      form.in_stock ? 'bg-ink-900' : 'bg-ink-200'
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                        form.in_stock ? 'translate-x-5' : ''
                      }`}
                    />
                  </button>
                </label>
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-sm font-medium text-ink-900">
                    Featured on homepage
                  </span>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, featured: !form.featured })}
                    className={`relative w-11 h-6 rounded-full transition-colors ${
                      form.featured ? 'bg-ink-900' : 'bg-ink-200'
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                        form.featured ? 'translate-x-5' : ''
                      }`}
                    />
                  </button>
                </label>
              </div>

              <div className="flex gap-3 pt-4 border-t border-ink-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    resetForm();
                  }}
                  className="flex-1 border border-ink-200 text-ink-700 py-3 rounded-full text-sm font-semibold hover:bg-ink-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-ink-900 text-white py-3 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {saving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      {editingId ? 'Save changes' : 'Add product'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
