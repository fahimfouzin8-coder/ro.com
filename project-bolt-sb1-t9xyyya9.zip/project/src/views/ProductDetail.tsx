import { useState } from 'react';
import { ArrowLeft, Check, ShoppingBag, Minus, Plus } from 'lucide-react';
import type { Product } from '../lib/supabase';
import { useCart } from '../context/CartContext';

type ProductDetailProps = {
  product: Product;
  onBack: () => void;
};

export default function ProductDetail({ product, onBack }: ProductDetailProps) {
  const { addItem } = useCart();
  const [size, setSize] = useState<string>(product.sizes[0] ?? '');
  const [color, setColor] = useState<string>(product.colors[0] ?? '');
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addItem(product, size, color, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 animate-fade-in">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm text-ink-500 hover:text-ink-900 transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to shop
      </button>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-16">
        {/* Image */}
        <div className="aspect-[4/5] bg-ink-50 rounded-3xl overflow-hidden">
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Details */}
        <div className="flex flex-col">
          <div className="flex-1">
            {product.featured && (
              <span className="inline-block bg-ink-50 text-ink-600 text-[10px] font-semibold tracking-widest uppercase px-3 py-1.5 rounded-full mb-4">
                Featured
              </span>
            )}
            <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight mb-3">
              {product.name}
            </h1>
            <p className="font-display text-2xl font-semibold text-ink-900 mb-6">
              ${product.price.toFixed(2)}
            </p>
            <p className="text-ink-600 leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Color */}
            <div className="mb-6">
              <p className="text-sm font-medium text-ink-900 mb-3">
                Color — <span className="text-ink-500">{color}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={`px-4 py-2 rounded-full text-sm font-medium border transition-all ${
                      color === c
                        ? 'border-ink-900 bg-ink-900 text-white'
                        : 'border-ink-200 text-ink-700 hover:border-ink-400'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Size */}
            <div className="mb-6">
              <p className="text-sm font-medium text-ink-900 mb-3">
                Size — <span className="text-ink-500">{size}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSize(s)}
                    className={`min-w-[3rem] px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${
                      size === s
                        ? 'border-ink-900 bg-ink-900 text-white'
                        : 'border-ink-200 text-ink-700 hover:border-ink-400'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-8">
              <p className="text-sm font-medium text-ink-900 mb-3">Quantity</p>
              <div className="inline-flex items-center border border-ink-200 rounded-xl">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="p-3 hover:bg-ink-50 rounded-l-xl transition-colors"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-6 py-2.5 text-sm font-medium min-w-[3rem] text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="p-3 hover:bg-ink-50 rounded-r-xl transition-colors"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Add to cart */}
          <button
            onClick={handleAdd}
            disabled={!product.in_stock}
            className={`w-full flex items-center justify-center gap-2 py-4 rounded-full text-sm font-semibold transition-all ${
              !product.in_stock
                ? 'bg-ink-100 text-ink-400 cursor-not-allowed'
                : added
                ? 'bg-green-600 text-white'
                : 'bg-ink-900 text-white hover:bg-ink-800'
            }`}
          >
            {!product.in_stock ? (
              'Sold Out'
            ) : added ? (
              <>
                <Check className="w-4 h-4" />
                Added to bag
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" />
                Add to bag — ${(product.price * quantity).toFixed(2)}
              </>
            )}
          </button>

          {/* Details list */}
          <div className="mt-8 pt-8 border-t border-ink-100 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-ink-400">Material</span>
              <span className="text-ink-700 font-medium">100% Heavyweight Cotton</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-ink-400">Fit</span>
              <span className="text-ink-700 font-medium">Regular</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-ink-400">Care</span>
              <span className="text-ink-700 font-medium">Machine wash cold</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
