import { useEffect, useState } from 'react';
import { supabase, type Product } from '../lib/supabase';
import ProductCard from '../components/ProductCard';
import { Loader2 } from 'lucide-react';

type ShopProps = {
  onSelectProduct: (product: Product) => void;
};

export default function Shop({ onSelectProduct }: ShopProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'featured'>('all');

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) {
        setError(error.message);
      } else {
        setProducts(data ?? []);
      }
      setLoading(false);
    }
    load();
  }, []);

  const displayed =
    filter === 'featured' ? products.filter((p) => p.featured) : products;

  return (
    <div>
      {/* Hero */}
      <section className="bg-ink-950 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="max-w-2xl animate-slide-up">
            <p className="text-xs font-medium tracking-[0.3em] uppercase text-ink-400 mb-6">
              Premium Essentials
            </p>
            <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05] mb-6">
              Wear the<br />difference.
            </h1>
            <p className="text-ink-300 text-lg leading-relaxed max-w-md mb-8">
              Minimalist t-shirts crafted from heavyweight cotton. No logos, no noise — just clean design that lasts.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="#collection"
                className="bg-white text-ink-900 px-7 py-3.5 rounded-full text-sm font-semibold hover:bg-ink-100 transition-colors"
              >
                Shop Collection
              </a>
              <a
                href="#featured"
                className="border border-ink-700 text-white px-7 py-3.5 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors"
              >
                Featured
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      {products.some((p) => p.featured) && (
        <section id="featured" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-xs font-medium tracking-[0.3em] uppercase text-ink-400 mb-3">
                Curated
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
                Featured Pieces
              </h2>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-10">
            {products
              .filter((p) => p.featured)
              .slice(0, 4)
              .map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => onSelectProduct(product)}
                />
              ))}
          </div>
        </section>
      )}

      {/* Collection */}
      <section
        id="collection"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 border-t border-ink-100"
      >
        <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
          <div>
            <p className="text-xs font-medium tracking-[0.3em] uppercase text-ink-400 mb-3">
              All Products
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
              The Collection
            </h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === 'all'
                  ? 'bg-ink-900 text-white'
                  : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('featured')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === 'featured'
                  ? 'bg-ink-900 text-white'
                  : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
              }`}
            >
              Featured
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-24">
            <Loader2 className="w-6 h-6 animate-spin text-ink-400" />
          </div>
        ) : error ? (
          <div className="text-center py-24">
            <p className="text-ink-500">Couldn't load products.</p>
            <p className="text-ink-400 text-sm mt-1">{error}</p>
          </div>
        ) : displayed.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-ink-500 text-lg">No products yet.</p>
            <p className="text-ink-400 text-sm mt-2">
              Add some from the Admin panel.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-10">
            {displayed.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onClick={() => onSelectProduct(product)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
