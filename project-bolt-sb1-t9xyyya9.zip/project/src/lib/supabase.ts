import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  sizes: string[];
  colors: string[];
  category: string;
  in_stock: boolean;
  featured: boolean;
  created_at: string;
};

export type CartItem = {
  product: Product;
  size: string;
  color: string;
  quantity: number;
};
