import { useState } from 'react';
import { CartProvider } from './context/CartContext';
import Header from './components/Header';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import Shop from './views/Shop';
import ProductDetail from './views/ProductDetail';
import Admin from './views/Admin';
import type { Product } from './lib/supabase';

type View = 'shop' | 'admin' | 'product';

function App() {
  const [view, setView] = useState<View>('shop');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleNavigate = (v: 'shop' | 'admin') => {
    setView(v);
    setSelectedProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setView('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    setView('shop');
    setSelectedProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col bg-white">
        <Header
          onNavigate={handleNavigate}
          currentView={view === 'product' ? 'shop' : view}
        />
        <main className="flex-1">
          {view === 'shop' && <Shop onSelectProduct={handleSelectProduct} />}
          {view === 'product' && selectedProduct && (
            <ProductDetail product={selectedProduct} onBack={handleBack} />
          )}
          {view === 'admin' && <Admin />}
        </main>
        <Footer />
        <CartDrawer />
      </div>
    </CartProvider>
  );
}

export default App;
