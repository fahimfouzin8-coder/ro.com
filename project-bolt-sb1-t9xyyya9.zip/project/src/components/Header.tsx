import { ShoppingBag, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';

type HeaderProps = {
  onNavigate: (view: 'shop' | 'admin') => void;
  currentView: 'shop' | 'admin';
};

export default function Header({ onNavigate, currentView }: HeaderProps) {
  const { totalItems, openCart } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-ink-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <button
            onClick={() => onNavigate('shop')}
            className="font-display text-2xl md:text-3xl font-bold tracking-tight text-ink-900 hover:text-ink-700 transition-colors"
          >
            RO
          </button>

          <nav className="hidden md:flex items-center gap-8">
            <button
              onClick={() => onNavigate('shop')}
              className={`text-sm font-medium tracking-wide transition-colors ${
                currentView === 'shop'
                  ? 'text-ink-900'
                  : 'text-ink-400 hover:text-ink-900'
              }`}
            >
              Shop
            </button>
            <button
              onClick={() => onNavigate('admin')}
              className={`text-sm font-medium tracking-wide transition-colors ${
                currentView === 'admin'
                  ? 'text-ink-900'
                  : 'text-ink-400 hover:text-ink-900'
              }`}
            >
              Admin
            </button>
          </nav>

          <div className="flex items-center gap-3">
            <button
              onClick={openCart}
              className="relative p-2 hover:bg-ink-50 rounded-full transition-colors"
              aria-label="Open cart"
            >
              <ShoppingBag className="w-5 h-5 text-ink-900" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-ink-900 text-white text-[10px] font-semibold rounded-full w-4 h-4 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2 hover:bg-ink-50 rounded-full transition-colors"
              aria-label="Toggle menu"
            >
              {mobileOpen ? (
                <X className="w-5 h-5 text-ink-900" />
              ) : (
                <Menu className="w-5 h-5 text-ink-900" />
              )}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t border-ink-100 py-4 animate-fade-in">
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  onNavigate('shop');
                  setMobileOpen(false);
                }}
                className={`text-left text-sm font-medium px-2 py-2 rounded-lg transition-colors ${
                  currentView === 'shop'
                    ? 'text-ink-900 bg-ink-50'
                    : 'text-ink-400 hover:text-ink-900'
                }`}
              >
                Shop
              </button>
              <button
                onClick={() => {
                  onNavigate('admin');
                  setMobileOpen(false);
                }}
                className={`text-left text-sm font-medium px-2 py-2 rounded-lg transition-colors ${
                  currentView === 'admin'
                    ? 'text-ink-900 bg-ink-50'
                    : 'text-ink-400 hover:text-ink-900'
                }`}
              >
                Admin
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
