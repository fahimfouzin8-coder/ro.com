import type { Product } from '../lib/supabase';

type ProductCardProps = {
  product: Product;
  onClick: () => void;
};

export default function ProductCard({ product, onClick }: ProductCardProps) {
  return (
    <button
      onClick={onClick}
      className="group text-left animate-slide-up"
    >
      <div className="relative aspect-[4/5] bg-ink-50 overflow-hidden rounded-2xl mb-4">
        <img
          src={product.image_url}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {!product.in_stock && (
          <div className="absolute inset-0 bg-white/60 flex items-center justify-center">
            <span className="bg-ink-900 text-white text-xs font-semibold tracking-widest uppercase px-4 py-2 rounded-full">
              Sold Out
            </span>
          </div>
        )}
        {product.featured && product.in_stock && (
          <span className="absolute top-3 left-3 bg-white text-ink-900 text-[10px] font-semibold tracking-widest uppercase px-3 py-1.5 rounded-full">
            Featured
          </span>
        )}
      </div>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-medium text-ink-900 truncate group-hover:text-ink-600 transition-colors">
            {product.name}
          </h3>
          <p className="text-xs text-ink-400 mt-1 capitalize">
            {product.colors.slice(0, 2).join(' · ')}
            {product.colors.length > 2 && ` +${product.colors.length - 2}`}
          </p>
        </div>
        <p className="font-display font-semibold text-ink-900 whitespace-nowrap">
          ${product.price.toFixed(2)}
        </p>
      </div>
    </button>
  );
}
