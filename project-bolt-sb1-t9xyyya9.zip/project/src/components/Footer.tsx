export default function Footer() {
  return (
    <footer className="bg-ink-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <h2 className="font-display text-3xl font-bold tracking-tight mb-3">RO</h2>
            <p className="text-ink-400 text-sm leading-relaxed max-w-xs">
              Premium heavyweight t-shirts. Minimal design, maximum comfort. Built to last.
            </p>
          </div>
          <div>
            <h3 className="text-xs font-medium tracking-[0.2em] uppercase text-ink-500 mb-4">
              Shop
            </h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#collection" className="text-ink-300 hover:text-white transition-colors">All products</a></li>
              <li><a href="#featured" className="text-ink-300 hover:text-white transition-colors">Featured</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xs font-medium tracking-[0.2em] uppercase text-ink-500 mb-4">
              Support
            </h3>
            <ul className="space-y-2 text-sm">
              <li><span className="text-ink-300">Shipping & returns</span></li>
              <li><span className="text-ink-300">Size guide</span></li>
              <li><span className="text-ink-300">Contact</span></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-ink-800 flex flex-col sm:flex-row justify-between gap-4 text-xs text-ink-500">
          <p>© {new Date().getFullYear()} RO. All rights reserved.</p>
          <p>Designed for those who notice the details.</p>
        </div>
      </div>
    </footer>
  );
}
