import { useState } from 'react';
import { X, Minus, Plus, ShoppingBag, Trash2, Check, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, subtotal, clearCart } =
    useCart();
  const [checkout, setCheckout] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const shipping = subtotal > 75 ? 0 : subtotal > 0 ? 6.5 : 0;
  const total = subtotal + shipping;

  const handleCheckout = () => {
    setOrderPlaced(true);
    clearCart();
    setTimeout(() => {
      setOrderPlaced(false);
      setCheckout(false);
      closeCart();
    }, 2500);
  };

  const handleClose = () => {
    setCheckout(false);
    setOrderPlaced(false);
    closeCart();
  };

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-ink-950/40 backdrop-blur-sm z-50 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={handleClose}
      />

      {/* Drawer */}
      <aside
        className={`fixed top-0 right-0 bottom-0 w-full max-w-md bg-white z-50 shadow-2xl flex flex-col transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-ink-100">
          <h2 className="font-display text-lg font-bold flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            {checkout ? 'Checkout' : 'Your Bag'}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-ink-50 rounded-full transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {orderPlaced ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center animate-fade-in">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-5">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="font-display text-2xl font-bold mb-2">Order placed!</h3>
            <p className="text-ink-500 text-sm">
              Thank you. A confirmation has been sent to your email.
            </p>
          </div>
        ) : items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
            <div className="w-16 h-16 bg-ink-50 rounded-full flex items-center justify-center mb-5">
              <ShoppingBag className="w-7 h-7 text-ink-300" />
            </div>
            <h3 className="font-display text-xl font-bold mb-2">Your bag is empty</h3>
            <p className="text-ink-500 text-sm mb-6">
              Add some pieces to get started.
            </p>
            <button
              onClick={handleClose}
              className="bg-ink-900 text-white px-6 py-3 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors"
            >
              Continue shopping
            </button>
          </div>
        ) : checkout ? (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <div className="space-y-5">
                <div>
                  <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                    Email
                  </label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                    Shipping address
                  </label>
                  <input
                    type="text"
                    placeholder="Street address"
                    className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors mb-2"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="City"
                      className="px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                    />
                    <input
                      type="text"
                      placeholder="ZIP"
                      className="px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-ink-500 mb-2 tracking-wide uppercase">
                    Card details
                  </label>
                  <input
                    type="text"
                    placeholder="Card number"
                    className="w-full px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors mb-2"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM / YY"
                      className="px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      className="px-4 py-3 rounded-xl border border-ink-200 focus:border-ink-900 focus:ring-1 focus:ring-ink-900 outline-none text-sm transition-colors"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="border-t border-ink-100 px-6 py-5">
              <div className="space-y-2 mb-4 text-sm">
                <div className="flex justify-between text-ink-500">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-ink-500">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between font-semibold text-ink-900 pt-2 border-t border-ink-100">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={handleCheckout}
                className="w-full bg-ink-900 text-white py-4 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors flex items-center justify-center gap-2"
              >
                Place order
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCheckout(false)}
                className="w-full text-center text-sm text-ink-500 hover:text-ink-900 mt-3 transition-colors"
              >
                Back to bag
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={index} className="flex gap-4 animate-slide-in-right">
                    <div className="w-20 h-24 bg-ink-50 rounded-xl overflow-hidden flex-shrink-0">
                      <img
                        src={item.product.image_url}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between gap-2">
                        <h4 className="font-medium text-sm text-ink-900 truncate">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeItem(index)}
                          className="text-ink-300 hover:text-ink-900 transition-colors flex-shrink-0"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-xs text-ink-400 mt-0.5">
                        {item.color} · {item.size}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="inline-flex items-center border border-ink-200 rounded-lg">
                          <button
                            onClick={() => updateQuantity(index, item.quantity - 1)}
                            className="p-1.5 hover:bg-ink-50 rounded-l-lg transition-colors"
                            aria-label="Decrease"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-3 text-xs font-medium">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(index, item.quantity + 1)}
                            className="p-1.5 hover:bg-ink-50 rounded-r-lg transition-colors"
                            aria-label="Increase"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <p className="font-semibold text-sm">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="border-t border-ink-100 px-6 py-5">
              <div className="space-y-2 mb-4 text-sm">
                <div className="flex justify-between text-ink-500">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-ink-500">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                {subtotal < 75 && subtotal > 0 && (
                  <p className="text-xs text-ink-400 pt-1">
                    Add ${(75 - subtotal).toFixed(2)} more for free shipping.
                  </p>
                )}
                <div className="flex justify-between font-semibold text-ink-900 pt-2 border-t border-ink-100">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={() => setCheckout(true)}
                className="w-full bg-ink-900 text-white py-4 rounded-full text-sm font-semibold hover:bg-ink-800 transition-colors flex items-center justify-center gap-2"
              >
                Checkout
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
